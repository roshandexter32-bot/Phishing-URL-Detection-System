"""Command-line phishing URL detector (hybrid rules + Random Forest).

Usage:
    python src/detect.py "http://paypal.secure-login.xyz/verify"
    python src/detect.py --file urls.txt
    python src/detect.py            # interactive mode
"""
import argparse
from pathlib import Path

import joblib
import pandas as pd

from features import FEATURE_NAMES, extract_features
from rules import rule_analysis

MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "phishing_rf.joblib"
W_ML = 0.7


def analyze(url: str, model=None):
    model = model or joblib.load(MODEL_PATH)
    feats = extract_features(url)
    ml_prob = float(model.predict_proba(pd.DataFrame([[feats[n] for n in FEATURE_NAMES]],
                                                     columns=FEATURE_NAMES))[0][1])
    rule_score, reasons = rule_analysis(url)
    score = W_ML * ml_prob + (1 - W_ML) * rule_score
    label = "PHISHING" if score >= 0.65 else "SUSPICIOUS" if score >= 0.40 else "LEGITIMATE"
    return {"url": url, "label": label, "score": round(score, 3),
            "ml_probability": round(ml_prob, 3), "rule_score": round(rule_score, 3),
            "reasons": reasons, "features": feats}


def show(r, verbose=False):
    print("=" * 70)
    print(f"URL        : {r['url']}")
    print(f"Verdict    : {r['label']}   (risk score {r['score']})")
    print(f"ML prob.   : {r['ml_probability']}   Rule score: {r['rule_score']}")
    print("Reasons    :")
    for x in (r["reasons"] or ["No suspicious indicators found"]):
        print(f"   - {x}")
    if verbose:
        print("Features   :", r["features"])


def main():
    ap = argparse.ArgumentParser(description="Phishing URL detector")
    ap.add_argument("url", nargs="?")
    ap.add_argument("--file", help="text file with one URL per line")
    ap.add_argument("-v", "--verbose", action="store_true", help="print extracted features")
    a = ap.parse_args()
    model = joblib.load(MODEL_PATH)
    if a.file:
        for line in Path(a.file).read_text().splitlines():
            if line.strip():
                show(analyze(line.strip(), model), a.verbose)
    elif a.url:
        show(analyze(a.url, model), a.verbose)
    else:
        print("Interactive mode - type a URL (or 'q' to quit)")
        while True:
            u = input("URL> ").strip()
            if u.lower() in ("q", "quit", "exit"):
                break
            if u:
                show(analyze(u, model), a.verbose)


if __name__ == "__main__":
    main()
