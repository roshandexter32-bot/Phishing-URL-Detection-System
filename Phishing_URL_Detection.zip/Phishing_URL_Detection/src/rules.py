"""Rule-based scoring + human-readable reasons."""
from features import extract_features


def rule_analysis(url: str):
    """Return (score 0..1, list of reasons). Higher = more suspicious."""
    f = extract_features(url)
    pts, reasons = 0.0, []

    def add(cond, w, msg):
        nonlocal pts
        if cond:
            pts += w
            reasons.append(msg)

    add(f["has_ip_address"], 3, "Host is a raw IP address instead of a domain name")
    add(f["has_at_symbol"], 2, "URL contains '@' (can hide the real destination)")
    add(f["is_shortener"], 1.5, "Uses a URL-shortening service (hides final destination)")
    add(f["suspicious_tld"], 1.5, "Uses a TLD commonly abused for phishing")
    add(f["brand_in_subdomain_or_path"], 2, "Brand name appears in subdomain/path/lookalike domain")
    add(f["num_suspicious_keywords"] >= 2, 1.5,
        f"Multiple suspicious keywords ({f['num_suspicious_keywords']}) such as login/verify/secure")
    add(f["num_suspicious_keywords"] == 1, 0.5, "Contains a suspicious keyword")
    add(f["num_subdomains"] >= 3, 1.5, f"Excessive subdomains ({f['num_subdomains']})")
    add(f["num_hyphens"] >= 2, 1, f"Many hyphens in host ({f['num_hyphens']})")
    add(f["url_length"] > 75, 1, f"Very long URL ({f['url_length']} characters)")
    add(f["has_port"], 1, "Uses a non-standard port")
    add(f["double_slash_in_path"], 1, "Contains '//' redirection inside the path")
    add(not f["uses_https"], 0.5, "Does not use HTTPS")
    add(f["digit_ratio"] > 0.25, 1, "Unusually high proportion of digits")
    return min(pts / 8.0, 1.0), reasons
