"""Train + evaluate. Compares: rule-based, ML (Random Forest), and hybrid."""
import json
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, ConfusionMatrixDisplay)
from sklearn.model_selection import train_test_split

from features import FEATURE_NAMES, feature_vector
from rules import rule_analysis

ROOT = Path(__file__).resolve().parent.parent
HYBRID_WEIGHT_ML = 0.7


def metrics(y, pred):
    return {
        "accuracy": round(accuracy_score(y, pred), 4),
        "precision": round(precision_score(y, pred), 4),
        "recall": round(recall_score(y, pred), 4),
        "f1_score": round(f1_score(y, pred), 4),
        "confusion_matrix": confusion_matrix(y, pred).tolist(),
    }


def save_cm(y, pred, title, fname):
    fig, ax = plt.subplots(figsize=(4.5, 4))
    ConfusionMatrixDisplay(confusion_matrix(y, pred),
                           display_labels=["Legitimate", "Phishing"]).plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(ROOT / "reports" / fname, dpi=150)
    plt.close(fig)


def main():
    df = pd.read_csv(ROOT / "data" / "urls_dataset.csv").dropna().drop_duplicates("url")
    print(f"Dataset: {len(df)} URLs | phishing={int(df.label.sum())} legit={int((df.label==0).sum())}")
    X = pd.DataFrame([feature_vector(u) for u in df.url], columns=FEATURE_NAMES)
    y = df.label.values
    idx = list(range(len(df)))
    tr, te = train_test_split(idx, test_size=0.2, stratify=y, random_state=42)
    Xtr, Xte, ytr, yte = X.iloc[tr], X.iloc[te], y[tr], y[te]
    urls_te = df.url.values[te]

    model = RandomForestClassifier(n_estimators=200, max_depth=12, random_state=42, n_jobs=-1)
    model.fit(Xtr, ytr)
    ml_prob = model.predict_proba(Xte)[:, 1]
    rule_score = [rule_analysis(u)[0] for u in urls_te]
    hybrid = HYBRID_WEIGHT_ML * ml_prob + (1 - HYBRID_WEIGHT_ML) * pd.Series(rule_score).values

    results = {
        "train_size": len(tr), "test_size": len(te),
        "rule_based": metrics(yte, (pd.Series(rule_score) >= 0.35).astype(int)),
        "machine_learning": metrics(yte, (ml_prob >= 0.5).astype(int)),
        "hybrid": metrics(yte, (hybrid >= 0.5).astype(int)),
    }
    imp = sorted(zip(FEATURE_NAMES, model.feature_importances_), key=lambda t: -t[1])
    results["top_features"] = [(n, round(float(v), 4)) for n, v in imp[:10]]

    # error analysis (ML model)
    pred = (ml_prob >= 0.5).astype(int)
    fp = [u for u, a, p in zip(urls_te, yte, pred) if a == 0 and p == 1][:10]
    fn = [u for u, a, p in zip(urls_te, yte, pred) if a == 1 and p == 0][:10]
    results["false_positive_examples"], results["false_negative_examples"] = fp, fn

    joblib.dump(model, ROOT / "models" / "phishing_rf.joblib")
    (ROOT / "reports" / "metrics.json").write_text(json.dumps(results, indent=2))
    save_cm(yte, pred, "Random Forest (ML)", "confusion_matrix_ml.png")
    save_cm(yte, (hybrid >= 0.5).astype(int), "Hybrid (Rules + ML)", "confusion_matrix_hybrid.png")

    fig, ax = plt.subplots(figsize=(7, 4))
    names, vals = zip(*imp[:10][::-1])
    ax.barh(names, vals, color="#2b6cb0")
    ax.set_title("Top 10 Feature Importances")
    fig.tight_layout()
    fig.savefig(ROOT / "reports" / "feature_importance.png", dpi=150)

    print(f"\n{'Approach':<18}{'Acc':>8}{'Prec':>8}{'Rec':>8}{'F1':>8}")
    for k in ("rule_based", "machine_learning", "hybrid"):
        m = results[k]
        print(f"{k:<18}{m['accuracy']:>8}{m['precision']:>8}{m['recall']:>8}{m['f1_score']:>8}")
        print(f"   confusion matrix [[TN FP],[FN TP]] = {m['confusion_matrix']}")
    print("\nTop features:", results["top_features"][:5])
    print("Saved model + reports to models/ and reports/")


if __name__ == "__main__":
    main()
