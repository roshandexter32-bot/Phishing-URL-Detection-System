"""URL feature extraction for phishing detection.

Every feature is a simple, explainable property of the URL string.
"""
import math
import re
from urllib.parse import urlparse

SUSPICIOUS_KEYWORDS = [
    "login", "signin", "verify", "update", "secure", "account", "banking",
    "confirm", "password", "wallet", "suspend", "invoice", "billing", "support",
]
SUSPICIOUS_TLDS = {"xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "work",
                   "link", "country", "icu", "buzz", "zip"}
SHORTENERS = {"bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd", "cutt.ly", "rb.gy"}
BRANDS = ["paypal", "google", "amazon", "microsoft", "apple", "facebook",
          "netflix", "instagram", "sbi", "hdfc", "icici", "paytm", "whatsapp"]
IP_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")

FEATURE_NAMES = [
    "url_length", "host_length", "path_length", "num_dots", "num_hyphens",
    "num_digits", "digit_ratio", "num_special_chars", "has_at_symbol",
    "has_ip_address", "uses_https", "num_subdomains", "has_port",
    "num_suspicious_keywords", "suspicious_tld", "is_shortener",
    "brand_in_subdomain_or_path", "double_slash_in_path", "num_query_params",
    "host_entropy",
]


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    probs = [s.count(c) / len(s) for c in set(s)]
    return -sum(p * math.log2(p) for p in probs)


def _parse(url: str):
    url = url.strip()
    if "://" not in url:
        url = "http://" + url
    p = urlparse(url)
    host = (p.hostname or "").lower()
    return url, p, host


def extract_features(url: str) -> dict:
    url, p, host = _parse(url)
    parts = host.split(".")
    is_ip = bool(IP_RE.match(host))
    tld = parts[-1] if parts else ""
    reg_domain = ".".join(parts[-2:]) if len(parts) >= 2 else host   # simple heuristic
    subdomain_labels = parts[:-2] if len(parts) > 2 else []
    low = url.lower()
    sub_and_path = ".".join(subdomain_labels) + p.path.lower()
    name = reg_domain.split(".")[0]
    # brand in subdomain/path, or lookalike (brand embedded in a different domain name)
    brand_hit = (not is_ip) and (
        any(b in sub_and_path for b in BRANDS)
        or any(b in name and name != b for b in BRANDS))
    digits = sum(c.isdigit() for c in url)
    try:
        port = p.port
    except ValueError:
        port = None
    return {
        "url_length": len(url),
        "host_length": len(host),
        "path_length": len(p.path),
        "num_dots": url.count("."),
        "num_hyphens": host.count("-"),
        "num_digits": digits,
        "digit_ratio": round(digits / max(len(url), 1), 4),
        "num_special_chars": sum(url.count(c) for c in "@?=&%_~#"),
        "has_at_symbol": int("@" in url),
        "has_ip_address": int(is_ip),
        "uses_https": int(p.scheme == "https"),
        "num_subdomains": len(subdomain_labels),
        "has_port": int(port not in (None, 80, 443)),
        "num_suspicious_keywords": sum(k in low for k in SUSPICIOUS_KEYWORDS),
        "suspicious_tld": int(tld in SUSPICIOUS_TLDS),
        "is_shortener": int(reg_domain in SHORTENERS),
        "brand_in_subdomain_or_path": int(brand_hit),
        "double_slash_in_path": int("//" in p.path),
        "num_query_params": len([q for q in p.query.split("&") if q]),
        "host_entropy": round(_entropy(host), 4),
    }


def feature_vector(url: str):
    f = extract_features(url)
    return [f[n] for n in FEATURE_NAMES]
