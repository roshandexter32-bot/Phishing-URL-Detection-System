"""Generate a labelled SYNTHETIC URL dataset (data/urls_dataset.csv).

NOTE: this is synthetic data modelled on real-world phishing patterns, used so
the project is fully reproducible offline. To use real data, put a CSV with
columns `url,label` (label: 1=phishing, 0=legitimate) at data/urls_dataset.csv
(e.g. from PhishTank / Kaggle) and re-run train.py.
"""
import csv
import random
import string
from pathlib import Path

random.seed(42)
LEGIT_DOMAINS = ["google.com", "wikipedia.org", "github.com", "amazon.in", "microsoft.com",
    "python.org", "stackoverflow.com", "linkedin.com", "youtube.com", "bbc.com", "nytimes.com",
    "flipkart.com", "irctc.co.in", "hdfcbank.com", "sbi.co.in", "nptel.ac.in", "coursera.org",
    "medium.com", "reddit.com", "apple.com", "netflix.com", "paypal.com", "zoho.com",
    "thehindu.com", "ndtv.com", "udemy.com", "mozilla.org", "cloudflare.com", "oracle.com", "ibm.com"]
LEGIT_PATHS = ["", "/", "/about", "/products", "/docs/getting-started", "/blog/2024/10/post-title",
    "/wiki/Cyber_security", "/search?q=network+security", "/courses/python-basics", "/news/world",
    "/help/contact-us", "/en/pricing", "/user/profile", "/careers", "/login", "/account/settings"]
LEGIT_SUBS = ["", "", "", "www.", "www.", "docs.", "mail.", "blog.", "support.", "m."]
BRANDS = ["paypal", "google", "amazon", "microsoft", "apple", "facebook", "netflix",
          "instagram", "sbi", "hdfc", "icici", "paytm", "whatsapp"]
KW = ["login", "signin", "verify", "update", "secure", "account", "banking", "confirm",
      "password", "wallet", "suspend", "billing", "support"]
BAD_TLDS = ["xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "work", "link", "icu", "buzz"]
OK_TLDS = ["com", "net", "org", "info", "online", "site", "co"]
SHORT = ["bit.ly", "tinyurl.com", "cutt.ly", "rb.gy", "is.gd"]


def rnd(n, chars=string.ascii_lowercase + string.digits):
    return "".join(random.choice(chars) for _ in range(n))


def legit():
    d = random.choice(LEGIT_DOMAINS)
    scheme = "https" if random.random() < 0.93 else "http"
    url = f"{scheme}://{random.choice(LEGIT_SUBS)}{d}{random.choice(LEGIT_PATHS)}"
    if random.random() < 0.12:  # long tracking-style legit URLs create overlap
        url += f"{'&' if '?' in url else '?'}utm_source={rnd(6)}&utm_campaign={rnd(8)}&id={random.randint(1000,99999)}"
    return url


def phishing():
    b, k1, k2 = random.choice(BRANDS), random.choice(KW), random.choice(KW)
    bad = random.choice(BAD_TLDS) if random.random() < 0.6 else random.choice(OK_TLDS)
    scheme = "https" if random.random() < 0.45 else "http"
    t = random.randint(0, 8)
    if t == 0:    # IP address host
        ip = ".".join(str(random.randint(1, 254)) for _ in range(4))
        return f"http://{ip}/{k1}/{b}/{rnd(6)}.php"
    if t == 1:    # brand as subdomain of an unrelated domain
        return f"{scheme}://{b}.{k1}-{rnd(5)}.{bad}/{k2}?id={rnd(10)}"
    if t == 2:    # hyphenated lookalike
        return f"{scheme}://{b}-{k1}-{k2}.{bad}/"
    if t == 3:    # long path with keywords
        return f"{scheme}://{rnd(8)}.{bad}/{k1}/{k2}/{b}/index.php?session={rnd(20)}&user={rnd(6)}"
    if t == 4:    # @ trick
        return f"{scheme}://www.{b}.com@{rnd(7)}.{bad}/{k1}"
    if t == 5:    # many subdomains
        return f"{scheme}://{k1}.{b}.{k2}.{rnd(4)}.{rnd(7)}.{bad}/{rnd(5)}"
    if t == 6:    # URL shortener
        return f"https://{random.choice(SHORT)}/{rnd(7, string.ascii_letters + string.digits)}"
    if t == 7:    # non-standard port + digits
        return f"http://{rnd(6)}{random.randint(10,999)}.{bad}:{random.choice([8080,8443,2083])}/{k1}.html"
    # subtle: looks clean, only keyword + lookalike domain
    return f"{scheme}://{b}{random.choice(['-', ''])}{k1}.{random.choice(OK_TLDS)}/{k2}"


def main(n_each=3000):
    rows = [(legit(), 0) for _ in range(n_each)] + [(phishing(), 1) for _ in range(n_each)]
    # 3% label noise so the problem is not trivially separable
    rows = [(u, 1 - y if random.random() < 0.03 else y) for u, y in rows]
    random.shuffle(rows)
    out = Path(__file__).resolve().parent.parent / "data" / "urls_dataset.csv"
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["url", "label"])
        w.writerows(rows)
    print(f"Wrote {len(rows)} rows to {out}")


if __name__ == "__main__":
    main()
