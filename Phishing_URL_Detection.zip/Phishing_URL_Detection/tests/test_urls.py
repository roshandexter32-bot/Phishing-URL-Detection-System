"""15 manual test URLs with expected vs actual results.
Run:  python tests/test_urls.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
import joblib
from detect import analyze, MODEL_PATH

# (url, expected) - expected is "LEGIT" or "PHISH"; SUSPICIOUS counts as a pass for PHISH
TESTS = [
    ("https://www.google.com", "LEGIT"),
    ("https://en.wikipedia.org/wiki/Phishing", "LEGIT"),
    ("https://github.com/python/cpython", "LEGIT"),
    ("https://www.amazon.in/", "LEGIT"),
    ("https://www.hdfcbank.com/personal/pay", "LEGIT"),
    ("https://nptel.ac.in/courses", "LEGIT"),
    ("https://www.linkedin.com/in/someone", "LEGIT"),
    ("http://paypal.secure-login-verify.xyz/account?id=88231", "PHISH"),
    ("http://192.168.45.12/login/paypal/update.php", "PHISH"),
    ("http://www.google.com@malicious-site.top/signin", "PHISH"),
    ("http://login.microsoft.verify.x7k2.abcd123.tk/confirm", "PHISH"),
    ("https://bit.ly/3xYzAbC", "PHISH"),
    ("http://sbi-netbanking-verify-account.top/", "PHISH"),
    ("http://amazon-support-billing.xyz:8080/update.html", "PHISH"),
    ("http://paytm-wallet-login.info/password", "PHISH"),
]


def main():
    model = joblib.load(MODEL_PATH)
    ok = 0
    lines = [f"{'#':<3}{'Expected':<10}{'Actual':<12}{'Score':<7}{'Result':<7}URL"]
    for i, (url, exp) in enumerate(TESTS, 1):
        r = analyze(url, model)
        flagged = r["label"] in ("PHISHING", "SUSPICIOUS")
        passed = flagged == (exp == "PHISH")
        ok += passed
        lines.append(f"{i:<3}{exp:<10}{r['label']:<12}{r['score']:<7}{'PASS' if passed else 'FAIL':<7}{url}")
    lines.append(f"\n{ok}/{len(TESTS)} test cases passed")
    out = "\n".join(lines)
    print(out)
    (Path(__file__).resolve().parent.parent / "reports" / "test_results.txt").write_text(out)


if __name__ == "__main__":
    main()
